import React from "react";
import { LV_ORDER, LV_SHORT, profCounts } from "@/data/dataUtils";

interface StackedBarProps {
  records: { lv: string }[];
  height?: number;
  onSegmentClick?: (level: string, records: { lv: string }[]) => void;
}

const levelColors: Record<string, string> = {
  "Above Proficiency": "bg-level-above",
  "At Proficiency": "bg-level-at",
  "Approaching Proficiency": "bg-level-approaching",
  "Below Proficiency": "bg-level-below",
};

export const StackedBar: React.FC<StackedBarProps> = ({ records, height = 20, onSegmentClick }) => {
  const counts = profCounts(records);
  const total = records.length || 1;

  return (
    <div className="flex rounded-lg overflow-hidden" style={{ height }} role="img" aria-label="Proficiency distribution">
      {LV_ORDER.map(lv => {
        const n = counts[lv];
        if (!n) return null;
        const pct = (n / total * 100).toFixed(1);
        return (
          <div
            key={lv}
            className={`${levelColors[lv]} transition-opacity hover:opacity-80 ${onSegmentClick ? "cursor-pointer" : ""}`}
            style={{ width: `${pct}%`, height }}
            title={`${LV_SHORT[lv]}: ${n} (${Math.round(+pct)}%)`}
            onClick={() => onSegmentClick?.(lv, records.filter(r => r.lv === lv))}
          />
        );
      })}
    </div>
  );
};

export const ProgressBar: React.FC<{ value: number | null; variant?: string; height?: number }> = ({ value, variant = "primary", height = 6 }) => {
  const p = value == null ? 0 : Math.round(value * 100);
  const colorMap: Record<string, string> = {
    primary: "bg-primary",
    above: "bg-level-above",
    at: "bg-level-at",
    approaching: "bg-level-approaching",
    below: "bg-level-below",
  };
  const barColor = p >= 80 ? colorMap.at : p >= 50 ? colorMap.approaching : colorMap.below;
  
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex-1 rounded-full overflow-hidden bg-secondary" style={{ height }}>
        <div className={`${variant === "auto" ? barColor : (colorMap[variant] || colorMap.primary)} rounded-full`} style={{ width: `${p}%`, height }} />
      </div>
      <span className="font-mono text-[10px] text-muted-foreground min-w-[28px] text-right">{p}%</span>
    </div>
  );
};

export default StackedBar;
