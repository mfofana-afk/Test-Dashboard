import React from "react";
import { getGradeSummary, getSchoolWeakStandards, D, buildLatest, buildILLookup, getStudentRisk, profCounts, LV_ORDER, LV_SHORT, stripGrade, buildTeachMap } from "@/data/dataUtils";
import KPICard from "@/components/KPICard";
import { StackedBar, ProgressBar } from "@/components/StackedBar";
import { RiskBadge } from "@/components/Badges";

const { latest } = buildLatest();
const ilLook = buildILLookup();
const teachMap = buildTeachMap();

export default function AdminDashboard({ onStudentClick }: { onStudentClick: (n: string) => void }) {
  const gradeSummary = getGradeSummary();
  const weakStds = getSchoolWeakStandards();
  const totalAtRisk = Object.values(latest).filter(r => getStudentRisk(r.n, latest, ilLook) === "high").length;
  const totalWatch = Object.values(latest).filter(r => getStudentRisk(r.n, latest, ilLook) === "watch").length;
  const totalStudents = Object.keys(latest).length;
  const overallPass = D.ilearnReadiness.length ? Math.round(D.ilearnReadiness.filter(r => r.cat === "Likely to Pass" || r.cat === "On Track").length / D.ilearnReadiness.length * 100) : 0;

  // Teacher growth trends
  const teacherData = D.classrooms.map(cl => {
    const recs = Object.values(latest).filter(r => r.hr === cl.Class || r.hr === cl.Grade + cl.Class);
    const counts = profCounts(recs);
    const total = recs.length || 1;
    const atAbove = Math.round((counts["Above Proficiency"] + counts["At Proficiency"]) / total * 100);
    const atRisk = recs.filter(r => getStudentRisk(r.n, latest, ilLook) === "high").length;
    return { ...cl, total: recs.length, atAbove, atRisk };
  });

  return (
    <div className="animate-fade-in">
      <div className="mb-5">
        <h2 className="text-lg font-bold text-navy mb-1">🏫 Admin Dashboard</h2>
        <p className="text-sm text-muted-foreground">School-wide performance overview — Where should we focus as a school?</p>
      </div>

      {/* School-wide KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
        <KPICard label="Total Students" value={totalStudents} variant="total" />
        <KPICard label="Est. ILEARN Pass" value={`${overallPass}%`} variant="pass" />
        <KPICard label="At Risk" value={totalAtRisk} sub={`${Math.round(totalAtRisk / totalStudents * 100)}% of students`} variant="below" />
        <KPICard label="Watch List" value={totalWatch} sub={`${Math.round(totalWatch / totalStudents * 100)}%`} variant="approaching" />
        <KPICard label="Focus Students" value={D.focusStudents.length} variant="focus" />
      </div>

      {/* Grade-level comparison */}
      <h3 className="text-base font-bold text-navy mb-3">Grade-Level Performance Comparison</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
        {gradeSummary.map(g => (
          <div key={g.grade} className="iq-group-card">
            <div className="p-4 border-b border-border" style={{ borderLeft: `4px solid ${g.grade === 4 ? "#f59e0b" : g.grade === 5 ? "#3b82f6" : "#10b981"}` }}>
              <div className="flex justify-between items-center">
                <div>
                  <div className="text-base font-bold text-navy">Grade {g.grade}</div>
                  <div className="text-xs text-muted-foreground">{g.total} students tested</div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold" style={{ color: g.grade === 4 ? "#f59e0b" : g.grade === 5 ? "#3b82f6" : "#10b981" }}>{g.atAbovePct}%</div>
                  <div className="text-[10px] text-muted-foreground">At/Above</div>
                </div>
              </div>
            </div>
            <div className="p-4 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">ILEARN Est. Pass</span>
                <span className="font-bold text-level-at">{g.ilPassPct}%</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">At Risk</span>
                <span className="font-bold text-destructive">{g.atRisk}</span>
              </div>
              {g.weakestStandards.length > 0 && (
                <div className="mt-2 pt-2 border-t border-border">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Weakest Standards</div>
                  {g.weakestStandards.map(std => (
                    <div key={std.code} className="flex justify-between items-center text-xs py-0.5">
                      <span className="font-mono font-bold text-primary">{std.code}</span>
                      <span className="text-destructive font-semibold">{Math.round(std.mastery * 100)}%</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Teacher Performance */}
      <h3 className="text-base font-bold text-navy mb-3">Class/Teacher Performance</h3>
      <div className="iq-card overflow-hidden mb-5">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr>
                {["Grade", "Class", "Teacher", "Students", "At/Above %", "At Risk", "Distribution"].map(h => (
                  <th key={h} className="bg-secondary/80 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground border-b whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {teacherData.sort((a, b) => b.atAbove - a.atAbove).map(t => (
                <tr key={t.Class} className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="px-3 py-2">{t.Grade}</td>
                  <td className="px-3 py-2 font-semibold">{t.Class}</td>
                  <td className="px-3 py-2">{t.Teacher}</td>
                  <td className="px-3 py-2">{t.total}</td>
                  <td className="px-3 py-2 font-bold">{t.atAbove}%</td>
                  <td className="px-3 py-2 text-destructive font-semibold">{t.atRisk}</td>
                  <td className="px-3 py-2 min-w-[140px]">
                    <StackedBar records={Object.values(latest).filter(r => r.hr === t.Class || r.hr === t.Grade + t.Class)} height={16} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* School-wide Weakest Standards */}
      <h3 className="text-base font-bold text-navy mb-3">🎯 School-Wide Weakest Standards — Focus Areas</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mb-5">
        {weakStds.map(std => (
          <div key={std.code} className="iq-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-mono font-bold text-primary text-sm">{std.code}</span>
              {std.priority === "Essential" && <span className="bg-level-approaching-bg text-level-approaching-text rounded px-1.5 py-0.5 text-[9px] font-bold">Essential</span>}
            </div>
            <div className="text-xs text-muted-foreground mb-1">{std.subdomain}</div>
            <div className="text-xs mb-3 line-clamp-2">{std.desc}</div>
            <div className="flex justify-between items-center">
              <div>
                <span className="text-destructive font-bold text-lg">{Math.round(std.mastery * 100)}%</span>
                <span className="text-xs text-muted-foreground ml-1">mastery</span>
              </div>
              <div className="text-right">
                <span className="text-destructive font-semibold">{std.below}</span>
                <span className="text-xs text-muted-foreground">/{std.n} below</span>
              </div>
            </div>
            <ProgressBar value={std.mastery} variant="auto" height={6} />
          </div>
        ))}
      </div>

      {/* Recommended focus */}
      <div className="iq-priority-panel">
        <h3 className="text-base font-bold mb-2">👉 Where Should We Focus as a School?</h3>
        <div className="space-y-2 text-sm opacity-90">
          <p>1. <strong>Priority Standards:</strong> {weakStds.slice(0, 2).map(s => s.code).join(", ")} — lowest mastery across all grades</p>
          <p>2. <strong>At-Risk Students:</strong> {totalAtRisk} students ({Math.round(totalAtRisk / totalStudents * 100)}%) need intensive support</p>
          <p>3. <strong>Quick Wins:</strong> {D.ilearnReadiness.filter(r => r.score >= 45 && r.score <= 55).length} border students could pass with targeted intervention</p>
          <p>4. <strong>ILEARN Readiness:</strong> Current estimated pass rate is {overallPass}%</p>
        </div>
      </div>
    </div>
  );
}
