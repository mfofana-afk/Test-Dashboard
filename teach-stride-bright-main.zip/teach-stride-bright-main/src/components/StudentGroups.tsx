import React from "react";
import { getSkillGroups, buildLatest, buildILLookup } from "@/data/dataUtils";
import { LevelBadge, RiskBadge } from "@/components/Badges";
import { getStudentRisk } from "@/data/dataUtils";

const { latest } = buildLatest();
const ilLook = buildILLookup();

export default function StudentGroups({ onStudentClick }: { onStudentClick: (n: string) => void }) {
  const groups = getSkillGroups();

  return (
    <div className="animate-fade-in">
      <div className="mb-5">
        <h2 className="text-lg font-bold text-navy mb-1">👥 Automatic Student Grouping</h2>
        <p className="text-sm text-muted-foreground">Students automatically grouped by skill gap and performance level — ready for instruction</p>
      </div>

      <div className="space-y-5">
        {groups.map((group, gi) => (
          <div key={gi} className="iq-group-card">
            <div className="p-4 border-b border-border" style={{
              background: group.level === "Below Proficiency" ? "linear-gradient(135deg, #fff5f5, #fee2e2)" :
                group.level === "Approaching Proficiency" ? "linear-gradient(135deg, #fffbeb, #fef3c7)" :
                group.level === "Near Threshold" ? "linear-gradient(135deg, #eff6ff, #dbeafe)" :
                group.level === "At Proficiency" ? "linear-gradient(135deg, #f0fdf4, #dcfce7)" :
                "linear-gradient(135deg, #eff6ff, #dbeafe)"
            }}>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="text-base font-bold text-navy">{group.name}</h3>
                  <div className="text-xs text-muted-foreground mt-0.5">{group.level} · {group.students.length} students</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-mono font-bold text-primary">{group.standard}</div>
                  <div className="text-xs text-muted-foreground">Target Standard</div>
                </div>
              </div>
            </div>

            <div className="p-4 space-y-3">
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">📋 Standard Description</div>
                <p className="text-sm text-foreground/80">{group.standardDesc}</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-secondary/50 rounded-lg p-3">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">🎯 Instructional Strategy</div>
                  <p className="text-sm">{group.strategy}</p>
                </div>
                <div className="bg-secondary/50 rounded-lg p-3">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">📌 Lesson Focus</div>
                  <p className="text-sm">{group.focus}</p>
                </div>
              </div>
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">Students ({group.students.length})</div>
                <div className="flex flex-wrap gap-1.5">
                  {group.students.slice(0, 30).map(name => {
                    const risk = getStudentRisk(name, latest, ilLook);
                    return (
                      <span
                        key={name}
                        className="iq-student-link text-xs bg-secondary/60 border border-border rounded-md px-2 py-1 hover:bg-secondary"
                        onClick={() => onStudentClick(name)}
                      >
                        {risk === "high" ? "🔴 " : risk === "watch" ? "🟡 " : "🟢 "}{name}
                      </span>
                    );
                  })}
                  {group.students.length > 30 && (
                    <span className="text-xs text-muted-foreground px-2 py-1">…and {group.students.length - 30} more</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
