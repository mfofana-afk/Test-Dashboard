import React, { useState, useMemo, useCallback } from "react";
import {
  D, buildLatest, buildIRLookup, buildTeachMap, buildILLookup, buildStuLookup,
  profCounts, stripGrade, LV_ORDER, LV_SHORT, getStudentRisk, getNextStep,
  getTopPriorityStandards, getSkillGroups, getGradeSummary, getSchoolWeakStandards,
  getPLCInsights, pct,
  type Checkpoint, type ILearnReadiness, type FocusStudent
} from "@/data/dataUtils";
import KPICard from "@/components/KPICard";
import { StackedBar, ProgressBar } from "@/components/StackedBar";
import { LevelBadge, RiskBadge, GrowthBadge, ScoreChip, SparkLine } from "@/components/Badges";
import StudentModal from "@/components/StudentModal";
import PriorityPanel from "@/components/PriorityPanel";
import StudentGroups from "@/components/StudentGroups";
import AdminDashboard from "@/components/AdminDashboard";
import PLCMode from "@/components/PLCMode";

// Pre-build lookups
const { latest, byNameCP } = buildLatest();
const irLook = buildIRLookup();
const teachMap = buildTeachMap();
const ilLook = buildILLookup();
const stuLook = buildStuLookup();
const focusSet = new Set(D.focusStudents.map(f => f.n));

type Tab = "overview" | "checkpoints" | "groups" | "ilearn" | "iready" | "standards" | "admin" | "plc";

const TABS: { id: Tab; label: string; emoji: string }[] = [
  { id: "overview", label: "Overview", emoji: "📊" },
  { id: "groups", label: "Groups", emoji: "👥" },
  { id: "checkpoints", label: "Checkpoints", emoji: "✅" },
  { id: "ilearn", label: "ILEARN", emoji: "🎯" },
  { id: "iready", label: "iReady", emoji: "📈" },
  { id: "standards", label: "Standards", emoji: "📐" },
  { id: "admin", label: "Admin", emoji: "🏫" },
  { id: "plc", label: "PLC Mode", emoji: "💬" },
];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [gradeFilter, setGradeFilter] = useState("");
  const [teacherFilter, setTeacherFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const allTeachers = useMemo(() => [...new Set(D.classrooms.map(c => c.Teacher))].sort(), []);
  const allHRs = useMemo(() => [...new Set(D.checkpoints.map(r => r.hr))].filter(Boolean).sort(), []);

  // Filtered overview records
  const filteredLatest = useMemo(() => {
    return Object.values(latest).filter(r => {
      if (gradeFilter && String(r.g) !== gradeFilter) return false;
      const t = teachMap[r.hr] || teachMap[stripGrade(r.hr)] || "";
      if (teacherFilter && t !== teacherFilter) return false;
      return true;
    });
  }, [gradeFilter, teacherFilter]);

  // Search handler
  const searchResults = useMemo(() => {
    if (!searchQuery || searchQuery.length < 2) return [];
    const q = searchQuery.toLowerCase();
    return D.students.filter(s => s.n.toLowerCase().includes(q)).slice(0, 8);
  }, [searchQuery]);

  const headerPassPct = useMemo(() => {
    const pass = D.ilearnReadiness.filter(r => r.cat === "Likely to Pass" || r.cat === "On Track").length;
    return D.ilearnReadiness.length ? Math.round(pass / D.ilearnReadiness.length * 100) : 0;
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="iq-header text-primary-foreground px-5 py-3 flex items-center gap-3 sticky top-0 z-50" style={{ boxShadow: "0 4px 24px rgba(30,27,75,0.4)" }}>
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-full bg-primary-foreground/20 border-2 border-primary-foreground/40 flex items-center justify-center font-bold text-sm">IQ</div>
          <div>
            <div className="text-base font-bold tracking-tight">InstructionIQ</div>
            <div className="text-[10.5px] opacity-70">From data to instruction in seconds · 2025–26</div>
          </div>
        </div>
        <div className="relative flex-1 max-w-xs">
          <div className="flex items-center gap-2 bg-primary-foreground/15 border border-primary-foreground/25 rounded-full px-3 py-1.5">
            <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" className="opacity-60"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input
              type="text"
              placeholder="Search any student…"
              className="bg-transparent border-none outline-none text-primary-foreground text-sm w-full placeholder:text-primary-foreground/50"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
          {searchResults.length > 0 && (
            <div className="absolute top-full mt-1.5 left-0 right-0 bg-card rounded-xl shadow-lg border z-50 max-h-72 overflow-y-auto">
              {searchResults.map(s => (
                <div
                  key={s.n}
                  className="px-3 py-2.5 border-b border-border/50 cursor-pointer hover:bg-secondary/50 flex gap-2 items-center"
                  onClick={() => { setSelectedStudent(s.n); setSearchQuery(""); }}
                >
                  <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-lavender text-navy-light font-semibold shrink-0">Student</span>
                  <div>
                    <div className="font-medium text-sm text-foreground">{s.n}</div>
                    <div className="text-[11px] text-muted-foreground">Gr{s.gr} · {stripGrade(s.hr)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="shrink-0 flex items-center gap-2">
          <div className="bg-primary-foreground/15 rounded-full px-3 py-1 text-xs whitespace-nowrap">Est. ILEARN Pass: {headerPassPct}%</div>
          <div className="bg-primary-foreground/15 rounded-full px-3 py-1 text-xs whitespace-nowrap">{D.students.length} Students</div>
        </div>
      </header>

      {/* Tabs */}
      <nav className="bg-card border-b border-border sticky top-[60px] z-40 px-5 flex gap-0.5 overflow-x-auto" style={{ boxShadow: "var(--shadow-sm)" }}>
        {TABS.map(tab => (
          <button
            key={tab.id}
            className={`iq-tab ${activeTab === tab.id ? "active" : ""}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.emoji} {tab.label}
          </button>
        ))}
      </nav>

      {/* Main */}
      <main className="p-5 max-w-[1600px] mx-auto">
        {activeTab === "overview" && (
          <OverviewTab
            filteredLatest={filteredLatest}
            gradeFilter={gradeFilter}
            setGradeFilter={setGradeFilter}
            teacherFilter={teacherFilter}
            setTeacherFilter={setTeacherFilter}
            allTeachers={allTeachers}
            onStudentClick={setSelectedStudent}
          />
        )}
        {activeTab === "groups" && <StudentGroups onStudentClick={setSelectedStudent} />}
        {activeTab === "checkpoints" && <CheckpointsTab onStudentClick={setSelectedStudent} />}
        {activeTab === "ilearn" && <ILearnTab onStudentClick={setSelectedStudent} />}
        {activeTab === "iready" && <IReadyTab onStudentClick={setSelectedStudent} />}
        {activeTab === "standards" && <StandardsTab onStudentClick={setSelectedStudent} />}
        {activeTab === "admin" && <AdminDashboard onStudentClick={setSelectedStudent} />}
        {activeTab === "plc" && <PLCMode onStudentClick={setSelectedStudent} />}
      </main>

      {/* Student Modal */}
      {selectedStudent && (
        <StudentModal
          studentName={selectedStudent}
          onClose={() => setSelectedStudent(null)}
          latest={latest}
          byNameCP={byNameCP}
          irLook={irLook}
          ilLook={ilLook}
          stuLook={stuLook}
          teachMap={teachMap}
          focusSet={focusSet}
        />
      )}
    </div>
  );
}

// ── Overview Tab ──
function OverviewTab({ filteredLatest, gradeFilter, setGradeFilter, teacherFilter, setTeacherFilter, allTeachers, onStudentClick }: {
  filteredLatest: Checkpoint[]; gradeFilter: string; setGradeFilter: (v: string) => void;
  teacherFilter: string; setTeacherFilter: (v: string) => void; allTeachers: string[];
  onStudentClick: (name: string) => void;
}) {
  const counts = profCounts(filteredLatest);
  const total = filteredLatest.length || 1;
  const ilPass = D.ilearnReadiness.filter(r => {
    const l = latest[r.n];
    if (!l) return false;
    if (gradeFilter && String(l.g) !== gradeFilter) return false;
    return r.cat === "Likely to Pass" || r.cat === "On Track";
  }).length;

  return (
    <div className="animate-fade-in">
      {/* Priority Panel */}
      <PriorityPanel gradeFilter={gradeFilter ? parseInt(gradeFilter) : undefined} />

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <h2 className="text-lg font-bold text-navy">School Overview</h2>
        <div className="flex items-center gap-2 ml-auto">
          <label className="text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">Grade</label>
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={gradeFilter} onChange={e => setGradeFilter(e.target.value)}>
            <option value="">All</option><option value="4">Gr 4</option><option value="5">Gr 5</option><option value="6">Gr 6</option>
          </select>
          <label className="text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground ml-2">Teacher</label>
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={teacherFilter} onChange={e => setTeacherFilter(e.target.value)}>
            <option value="">All</option>
            {allTeachers.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
      </div>

      {/* Legend */}
      <div className="flex gap-3 mb-3 flex-wrap">
        {[["Above", "bg-level-above"], ["At", "bg-level-at"], ["Approaching", "bg-level-approaching"], ["Below", "bg-level-below"]].map(([l, c]) => (
          <div key={l} className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className={`w-2 h-2 rounded-full ${c}`} />{l}
          </div>
        ))}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-5">
        <KPICard label="Tested" value={filteredLatest.length} sub={`${D.students.length} enrolled`} variant="total" />
        <KPICard label="Above" value={counts["Above Proficiency"]} sub={`${Math.round(counts["Above Proficiency"] / total * 100)}%`} variant="above" />
        <KPICard label="At" value={counts["At Proficiency"]} sub={`${Math.round(counts["At Proficiency"] / total * 100)}%`} variant="at" />
        <KPICard label="Approaching" value={counts["Approaching Proficiency"]} sub={`${Math.round(counts["Approaching Proficiency"] / total * 100)}%`} variant="approaching" />
        <KPICard label="Below" value={counts["Below Proficiency"]} sub={`${Math.round(counts["Below Proficiency"] / total * 100)}%`} variant="below" />
        <KPICard label="ILEARN Est. Pass" value={ilPass} sub={`${Math.round(ilPass / total * 100)}% of tested`} variant="pass" />
        <KPICard label="Focus Students" value={D.focusStudents.length} sub="data-identified" variant="focus" />
      </div>

      {/* Quick Wins */}
      <QuickWins gradeFilter={gradeFilter} onStudentClick={onStudentClick} />

      {/* By Grade */}
      <h3 className="text-base font-bold text-navy mb-3">By Grade</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
        {[4, 5, 6].filter(g => !gradeFilter || String(g) === gradeFilter).map(g => {
          const gr = Object.values(latest).filter(r => r.g === g);
          const gc = profCounts(gr);
          const gt = gr.length || 1;
          const atA = Math.round((gc["Above Proficiency"] + gc["At Proficiency"]) / gt * 100);
          return (
            <div key={g} className="iq-group-card">
              <div className="p-3.5 border-b border-border flex justify-between items-center" style={{ borderLeft: `4px solid ${g === 4 ? "#f59e0b" : g === 5 ? "#3b82f6" : "#10b981"}` }}>
                <div>
                  <div className="text-base font-bold text-navy">Grade {g}</div>
                  <div className="text-xs text-muted-foreground">{gr.length} tested</div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold" style={{ color: g === 4 ? "#f59e0b" : g === 5 ? "#3b82f6" : "#10b981" }}>{atA}%</div>
                  <div className="text-[10.5px] text-muted-foreground">At/Above</div>
                </div>
              </div>
              <div className="p-3.5">
                <StackedBar records={gr} />
                <div className="mt-3 space-y-1">
                  {LV_ORDER.map(lv => (
                    <div key={lv} className="flex items-center gap-2 text-xs">
                      <span className="min-w-[80px] text-muted-foreground">{LV_SHORT[lv]}</span>
                      <div className="flex-1"><ProgressBar value={gc[lv] / gt} variant="auto" /></div>
                      <span className="font-semibold min-w-[24px] text-right">{gc[lv]}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* By Homeroom */}
      <h3 className="text-base font-bold text-navy mb-3">By Homeroom</h3>
      <div className="space-y-1.5 mb-5">
        {(() => {
          const hrMap: Record<string, Checkpoint[]> = {};
          filteredLatest.forEach(r => { if (r.hr) { (hrMap[r.hr] ??= []).push(r); } });
          return Object.entries(hrMap).sort(([a], [b]) => a.localeCompare(b)).map(([cls, cr]) => {
            const cc = profCounts(cr);
            const ct = cr.length || 1;
            const atA = Math.round((cc["Above Proficiency"] + cc["At Proficiency"]) / ct * 100);
            const teach = teachMap[cls] || teachMap[stripGrade(cls)] || "";
            return (
              <div key={cls} className="flex items-center gap-3 p-3 bg-card border border-border rounded-lg">
                <div className="min-w-[120px]">
                  <div className="font-semibold text-sm">{stripGrade(cls)}</div>
                  <div className="text-xs text-muted-foreground">{teach}</div>
                </div>
                <div className="flex-1"><StackedBar records={cr} /></div>
                <div className="text-right min-w-[60px]">
                  <div className="text-sm font-bold text-navy">{atA}%</div>
                </div>
              </div>
            );
          });
        })()}
      </div>

      {/* Classes Table */}
      <div className="iq-card overflow-hidden mb-5">
        <div className="px-4 py-3 border-b border-border flex justify-between items-center">
          <span className="text-sm font-semibold text-navy">Classes & Teachers</span>
          <span className="text-xs text-muted-foreground bg-secondary rounded-full px-2 py-0.5">{D.classrooms.length} classes</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="iq-table">
              <th className="bg-secondary/50 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">Gr</th>
              <th className="bg-secondary/50 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">Class</th>
              <th className="bg-secondary/50 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">Teacher</th>
              <th className="bg-secondary/50 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">Tested</th>
              <th className="bg-secondary/50 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground min-w-[150px]">Distribution</th>
              <th className="bg-secondary/50 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">At/Above</th>
            </tr></thead>
            <tbody>
              {D.classrooms.map(cl => {
                const cr = Object.values(latest).filter(r => r.hr === cl.Class || r.hr === cl.Grade + cl.Class);
                const cc = profCounts(cr);
                const ct = cr.length || 1;
                const atA = Math.round((cc["Above Proficiency"] + cc["At Proficiency"]) / ct * 100);
                return (
                  <tr key={cl.Class} className="border-b border-border/50 hover:bg-secondary/30">
                    <td className="px-3 py-2">{cl.Grade}</td>
                    <td className="px-3 py-2 font-semibold">{cl.Class}</td>
                    <td className="px-3 py-2">{cl.Teacher}</td>
                    <td className="px-3 py-2">{cr.length}</td>
                    <td className="px-3 py-2"><StackedBar records={cr} height={16} /></td>
                    <td className="px-3 py-2 font-bold">{atA}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function QuickWins({ gradeFilter, onStudentClick }: { gradeFilter: string; onStudentClick: (n: string) => void }) {
  const border = D.ilearnReadiness
    .filter(r => {
      const l = latest[r.n]; if (!l) return false;
      if (gradeFilter && String(l.g) !== gradeFilter) return false;
      return r.score >= 48 && r.score <= 62 && r.cat === "On Track";
    })
    .sort((a, b) => b.score - a.score).slice(0, 5);
  
  if (!border.length) return null;
  return (
    <div className="rounded-xl p-3.5 mb-5 flex items-center gap-3 border" style={{ background: "linear-gradient(135deg, #fffbeb, #fef3c7)", borderColor: "#fde68a" }}>
      <span className="bg-level-approaching text-primary-foreground rounded-lg px-2.5 py-1 text-xs font-bold shrink-0">⚡ Quick Wins</span>
      <div className="flex-1">
        <div className="font-semibold text-sm mb-1">{border.length} students within reach of "Likely to Pass"</div>
        <div className="flex flex-wrap gap-1.5">
          {border.map(r => {
            const l = latest[r.n];
            return (
              <span key={r.n} className="iq-student-link bg-card border border-level-approaching-bg rounded-lg px-2.5 py-1 text-xs" onClick={() => onStudentClick(r.n)}>
                {r.n} <strong className="text-level-approaching">{r.score}</strong>
                {l && <span className="text-[10px] text-muted-foreground ml-1">Gr{l.g}</span>}
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── Checkpoints Tab ──
function CheckpointsTab({ onStudentClick }: { onStudentClick: (n: string) => void }) {
  const [cpGrade, setCpGrade] = useState("");
  const [cpSearch, setCpSearch] = useState("");

  const students = useMemo(() => {
    const names = new Set<string>();
    D.checkpoints.forEach(r => {
      if (cpGrade && String(r.g) !== cpGrade) return;
      if (cpSearch && !r.n.toLowerCase().includes(cpSearch.toLowerCase())) return;
      names.add(r.n);
    });
    return [...names].sort().slice(0, 200);
  }, [cpGrade, cpSearch]);

  return (
    <div className="animate-fade-in">
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <h2 className="text-lg font-bold text-navy">Checkpoint Results</h2>
        <div className="flex items-center gap-2 ml-auto">
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={cpGrade} onChange={e => setCpGrade(e.target.value)}>
            <option value="">All Grades</option><option value="4">Gr 4</option><option value="5">Gr 5</option><option value="6">Gr 6</option>
          </select>
          <input type="search" placeholder="Search student…" className="border rounded-md px-2 py-1 text-sm bg-card" value={cpSearch} onChange={e => setCpSearch(e.target.value)} />
        </div>
      </div>
      <div className="iq-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <span className="text-sm font-semibold text-navy">Student Checkpoint Summary</span>
          <span className="ml-2 text-xs text-muted-foreground bg-secondary rounded-full px-2 py-0.5">{students.length} students</span>
        </div>
        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr>
                {["Student", "Gr", "Homeroom", "CP1 Opp1", "CP1 Opp2", "CP2", "CP3", "Arc", "iReady", "ILEARN", "Risk"].map(h => (
                  <th key={h} className="bg-secondary/80 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground border-b whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {students.map(name => {
                const s = stuLook[name];
                const c1o1 = byNameCP[`${name}__1__1`];
                const c1o2 = byNameCP[`${name}__1__2`];
                const c2 = byNameCP[`${name}__2`];
                const c3 = byNameCP[`${name}__3`];
                const ir = irLook[name];
                const irm = ir?.moy || ir?.boy;
                const il = ilLook[name];
                const isFoc = focusSet.has(name);
                const allSc = [c1o1, c2, c3].map(r => r?.sc).filter(Boolean) as number[];
                const risk = getStudentRisk(name, latest, ilLook);
                return (
                  <tr key={name} className={`border-b border-border/50 hover:bg-secondary/30 ${isFoc ? "bg-level-at-bg/20" : ""}`}>
                    <td className="px-3 py-2">
                      <span className="iq-student-link" onClick={() => onStudentClick(name)}>{isFoc ? "⭐ " : ""}{name}</span>
                    </td>
                    <td className="px-3 py-2">{s?.gr || "—"}</td>
                    <td className="px-3 py-2 text-xs">{stripGrade(s?.hr || "—")}</td>
                    <td className="px-3 py-2"><LevelBadge level={c1o1?.lv || null} /></td>
                    <td className="px-3 py-2"><LevelBadge level={c1o2?.lv || null} /></td>
                    <td className="px-3 py-2"><LevelBadge level={c2?.lv || null} /></td>
                    <td className="px-3 py-2"><LevelBadge level={c3?.lv || null} /></td>
                    <td className="px-3 py-2"><SparkLine scores={allSc} /></td>
                    <td className="px-3 py-2">{irm ? <ScoreChip score={irm.sc} /> : "—"}</td>
                    <td className="px-3 py-2">{il ? <LevelBadge level={il.cat} /> : "—"}</td>
                    <td className="px-3 py-2"><RiskBadge risk={risk} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── ILEARN Tab ──
function ILearnTab({ onStudentClick }: { onStudentClick: (n: string) => void }) {
  const [ilGrade, setIlGrade] = useState("");
  const [ilCat, setIlCat] = useState("");

  const filtered = useMemo(() => {
    return D.ilearnReadiness.filter(r => {
      const l = latest[r.n]; if (!l) return false;
      if (ilGrade && String(l.g) !== ilGrade) return false;
      if (ilCat && r.cat !== ilCat) return false;
      return true;
    });
  }, [ilGrade, ilCat]);

  const catCounts = useMemo(() => {
    const c = { "Likely to Pass": 0, "On Track": 0, "Approaching": 0, "Needs Support": 0 };
    filtered.forEach(r => { if (r.cat in c) (c as any)[r.cat]++; });
    return c;
  }, [filtered]);

  const t = filtered.length || 1;

  return (
    <div className="animate-fade-in">
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <h2 className="text-lg font-bold text-navy">🎯 ILEARN Readiness Predictor</h2>
        <div className="flex items-center gap-2 ml-auto">
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={ilGrade} onChange={e => setIlGrade(e.target.value)}>
            <option value="">All Grades</option><option value="4">Gr 4</option><option value="5">Gr 5</option><option value="6">Gr 6</option>
          </select>
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={ilCat} onChange={e => setIlCat(e.target.value)}>
            <option value="">All Categories</option>
            {["Likely to Pass", "On Track", "Approaching", "Needs Support"].map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3 mb-5">
        <KPICard label="Analyzed" value={filtered.length} variant="total" />
        <KPICard label="Likely to Pass" value={catCounts["Likely to Pass"]} sub={`${Math.round(catCounts["Likely to Pass"] / t * 100)}%`} variant="at" />
        <KPICard label="On Track" value={catCounts["On Track"]} sub={`${Math.round(catCounts["On Track"] / t * 100)}%`} variant="above" />
        <KPICard label="Approaching" value={catCounts["Approaching"]} sub={`${Math.round(catCounts["Approaching"] / t * 100)}%`} variant="approaching" />
        <KPICard label="Needs Support" value={catCounts["Needs Support"]} sub={`${Math.round(catCounts["Needs Support"] / t * 100)}%`} variant="below" />
        <KPICard label="Est. Pass %" value={`${Math.round((catCounts["Likely to Pass"] + catCounts["On Track"]) / t * 100)}%`} sub="likely + on track" variant="pass" />
      </div>

      {/* Border Students */}
      <BorderStudents filtered={filtered} ilGrade={ilGrade} onStudentClick={onStudentClick} />

      {/* Full Table */}
      <div className="iq-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <span className="text-sm font-semibold text-navy">Full ILEARN Readiness Table</span>
          <span className="ml-2 text-xs text-muted-foreground bg-secondary rounded-full px-2 py-0.5">{filtered.length} rows</span>
        </div>
        <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr>
                {["Student", "Gr", "Homeroom", "Score", "Category", "Latest CP", "Level", "Risk", "Next Step"].map(h => (
                  <th key={h} className="bg-secondary/80 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground border-b whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.slice(0, 300).map(r => {
                const l = latest[r.n];
                if (!l) return null;
                const risk = getStudentRisk(r.n, latest, ilLook);
                const step = getNextStep(r.n, latest, ilLook);
                return (
                  <tr key={r.n} className="border-b border-border/50 hover:bg-secondary/30">
                    <td className="px-3 py-2"><span className="iq-student-link" onClick={() => onStudentClick(r.n)}>{focusSet.has(r.n) ? "⭐ " : ""}{r.n}</span></td>
                    <td className="px-3 py-2">{l.g}</td>
                    <td className="px-3 py-2 text-xs">{stripGrade(l.hr || "")}</td>
                    <td className="px-3 py-2 font-bold" style={{ color: r.cat === "Likely to Pass" ? "#10b981" : r.cat === "On Track" ? "#3b82f6" : r.cat === "Approaching" ? "#f59e0b" : "#ef4444" }}>{r.score}</td>
                    <td className="px-3 py-2"><LevelBadge level={r.cat} /></td>
                    <td className="px-3 py-2">CP{l.cp}</td>
                    <td className="px-3 py-2"><LevelBadge level={l.lv} /></td>
                    <td className="px-3 py-2"><RiskBadge risk={risk} /></td>
                    <td className="px-3 py-2 text-xs text-muted-foreground max-w-[200px] truncate" title={step}>{step}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function BorderStudents({ filtered, ilGrade, onStudentClick }: { filtered: ILearnReadiness[]; ilGrade: string; onStudentClick: (n: string) => void }) {
  const border = D.ilearnReadiness
    .filter(r => {
      const l = latest[r.n]; if (!l) return false;
      if (ilGrade && String(l.g) !== ilGrade) return false;
      return r.score >= 35 && r.score <= 55;
    })
    .sort((a, b) => b.score - a.score).slice(0, 20);

  if (!border.length) return null;
  return (
    <div className="iq-card overflow-hidden mb-5">
      <div className="px-4 py-3 border-b border-border">
        <span className="text-sm font-semibold text-navy">⚡ Border Students — Closest to Passing</span>
        <span className="ml-2 text-xs text-muted-foreground bg-secondary rounded-full px-2 py-0.5">{border.length} students</span>
      </div>
      <div className="max-h-[300px] overflow-y-auto">
        {border.map(r => {
          const l = latest[r.n];
          return (
            <div key={r.n} className="flex items-center gap-3 px-4 py-2.5 border-b border-border/50">
              {/* Mini gauge */}
              <div className="relative w-11 h-11 shrink-0">
                <svg width="44" height="44" viewBox="0 0 44 44" style={{ transform: "rotate(-90deg)" }}>
                  <circle cx="22" cy="22" r="17" fill="none" stroke="hsl(var(--lavender-dark))" strokeWidth="5" />
                  <circle cx="22" cy="22" r="17" fill="none" stroke={r.cat === "Likely to Pass" ? "#10b981" : r.cat === "On Track" ? "#3b82f6" : "#f59e0b"} strokeWidth="5" strokeDasharray={`${(r.score / 100) * 106.8} 106.8`} strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-navy">{r.score}</div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="iq-student-link text-sm" onClick={() => onStudentClick(r.n)}>{r.n}</span>
                  {l && <span className="text-xs text-muted-foreground">Gr{l.g} · {stripGrade(l.hr || "")}</span>}
                </div>
                <div className="w-full h-2 rounded-full bg-secondary overflow-hidden">
                  <div className="h-full rounded-full bg-level-approaching" style={{ width: `${r.score}%` }} />
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-sm font-bold text-level-approaching">{r.score}</div>
                <div className="text-[9px] text-muted-foreground">need {50 - r.score} more</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── iReady Tab ──
function IReadyTab({ onStudentClick }: { onStudentClick: (n: string) => void }) {
  const [irGrade, setIrGrade] = useState("");
  const [irPeriod, setIrPeriod] = useState("");

  const filtered = useMemo(() => {
    return D.iready.filter(r => {
      if (irGrade && String(r.gr) !== irGrade) return false;
      if (irPeriod && r.pd !== irPeriod) return false;
      return true;
    });
  }, [irGrade, irPeriod]);

  const boys = filtered.filter(r => r.pd === "boy");
  const moys = filtered.filter(r => r.pd === "moy");
  const avgB = boys.length ? Math.round(boys.reduce((a, r) => a + (r.sc || 0), 0) / boys.length) : null;
  const avgM = moys.length ? Math.round(moys.reduce((a, r) => a + (r.sc || 0), 0) / moys.length) : null;

  return (
    <div className="animate-fade-in">
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <h2 className="text-lg font-bold text-navy">📈 iReady Diagnostics</h2>
        <div className="flex items-center gap-2 ml-auto">
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={irGrade} onChange={e => setIrGrade(e.target.value)}>
            <option value="">All Grades</option><option value="4">Gr 4</option><option value="5">Gr 5</option><option value="6">Gr 6</option>
          </select>
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={irPeriod} onChange={e => setIrPeriod(e.target.value)}>
            <option value="">All Periods</option><option value="boy">BOY</option><option value="moy">MOY</option>
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <KPICard label="Records" value={filtered.length} sub={`BOY: ${boys.length} / MOY: ${moys.length}`} variant="total" />
        <KPICard label="BOY Avg" value={avgB ?? "—"} variant="approaching" />
        <KPICard label="MOY Avg" value={avgM ?? "—"} variant="at" />
        <KPICard label="Growth" value={avgB && avgM ? `+${avgM - avgB}` : "—"} sub="avg pts" variant="above" />
      </div>
      <div className="iq-card overflow-hidden">
        <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr>
                {["Student", "Gr", "Period", "Score", "Placement", "Relative Placement", "Percentile"].map(h => (
                  <th key={h} className="bg-secondary/80 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground border-b whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.slice(0, 400).map((r, i) => (
                <tr key={`${r.n}-${r.pd}-${i}`} className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="px-3 py-2"><span className="iq-student-link" onClick={() => onStudentClick(r.n)}>{r.n}</span></td>
                  <td className="px-3 py-2">{r.gr}</td>
                  <td className="px-3 py-2"><span className={r.pd === "boy" ? "iq-badge-approaching" : "iq-badge-at"}>{r.pd.toUpperCase()}</span></td>
                  <td className="px-3 py-2"><ScoreChip score={r.sc} /></td>
                  <td className="px-3 py-2 text-xs">{r.pl || "—"}</td>
                  <td className="px-3 py-2 text-xs">{r.rp || "—"}</td>
                  <td className="px-3 py-2 font-mono">{r.pct != null ? `${r.pct}th` : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Standards Tab ──
function StandardsTab({ onStudentClick }: { onStudentClick: (n: string) => void }) {
  const [sdGrade, setSdGrade] = useState("");
  const [sdSort, setSdSort] = useState("asc");

  const items = useMemo(() => {
    const grouped: Record<string, { code: string; g: number; cp: number; cat: string; mastery: number | null; n: number; below: number; proficient: number; desc: string }> = {};
    D.standards.forEach(s => {
      if (sdGrade && String(s.g) !== sdGrade) return;
      const key = `${s.code}__${s.cp}`;
      if (!grouped[key]) {
        const p = s.p > 0 ? s.e / s.p : null;
        const iaf = D.iaf[s.code];
        const below = s.students.filter(st => st.pct != null && st.pct < 0.6).length;
        const prof = s.students.filter(st => st.pct != null && st.pct >= 0.8).length;
        grouped[key] = { code: s.code, g: s.g, cp: s.cp, cat: iaf?.subdomain || s.cat, mastery: p, n: s.n, below, proficient: prof, desc: iaf?.desc || "" };
      }
    });
    const list = Object.values(grouped);
    list.sort((a, b) => sdSort === "asc" ? (a.mastery ?? -1) - (b.mastery ?? -1) : (b.mastery ?? -1) - (a.mastery ?? -1));
    return list;
  }, [sdGrade, sdSort]);

  return (
    <div className="animate-fade-in">
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <h2 className="text-lg font-bold text-navy">📐 Standards Performance</h2>
        <div className="flex items-center gap-2 ml-auto">
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={sdGrade} onChange={e => setSdGrade(e.target.value)}>
            <option value="">All Grades</option><option value="4">Gr 4</option><option value="5">Gr 5</option><option value="6">Gr 6</option>
          </select>
          <select className="border rounded-md px-2 py-1 text-sm bg-card" value={sdSort} onChange={e => setSdSort(e.target.value)}>
            <option value="asc">Lowest First</option><option value="desc">Highest First</option>
          </select>
        </div>
      </div>
      <div className="iq-card overflow-hidden">
        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr>
                {["Code", "Gr", "CP", "Subdomain", "n", "Mastery", "Struggling", "Proficient"].map(h => (
                  <th key={h} className="bg-secondary/80 px-3 py-2 text-left text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground border-b whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {items.map(it => (
                <tr key={`${it.code}-${it.cp}`} className="border-b border-border/50 hover:bg-secondary/30">
                  <td className="px-3 py-2">
                    <span className="font-mono font-bold text-primary">{it.code}</span>
                    {it.desc && <div className="text-[9.5px] text-muted-foreground max-w-[160px] truncate mt-0.5">{it.desc}</div>}
                  </td>
                  <td className="px-3 py-2">{it.g}</td>
                  <td className="px-3 py-2">CP{it.cp}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground max-w-[120px] truncate">{it.cat}</td>
                  <td className="px-3 py-2">{it.n}</td>
                  <td className="px-3 py-2 min-w-[120px]">
                    {it.mastery != null ? <ProgressBar value={it.mastery} variant="auto" /> : "—"}
                  </td>
                  <td className="px-3 py-2">
                    <span className="text-destructive font-semibold">{it.below}</span>
                    <span className="text-[10px] text-muted-foreground">/{it.n}</span>
                  </td>
                  <td className="px-3 py-2">
                    <span className="text-level-at font-semibold">{it.proficient}</span>
                    <span className="text-[10px] text-muted-foreground">/{it.n}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
