import React from "react";
import { LV_SHORT } from "@/data/dataUtils";

const badgeClasses: Record<string, string> = {
  "Above Proficiency": "iq-badge-above",
  "At Proficiency": "iq-badge-at",
  "Approaching Proficiency": "iq-badge-approaching",
  "Below Proficiency": "iq-badge-below",
  "Likely to Pass": "iq-badge-pass",
  "On Track": "iq-badge-track",
  "Approaching": "iq-badge-approaching",
  "Needs Support": "iq-badge-risk",
};

export const LevelBadge: React.FC<{ level: string | null }> = ({ level }) => {
  if (!level) return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-muted text-muted-foreground">—</span>;
  return <span className={badgeClasses[level] || "iq-badge-approaching"}>{LV_SHORT[level] || level}</span>;
};

export const RiskBadge: React.FC<{ risk: "high" | "watch" | "ontrack" }> = ({ risk }) => {
  const map = {
    high: { emoji: "🔴", text: "High Risk", cls: "iq-badge-risk" },
    watch: { emoji: "🟡", text: "Watch", cls: "iq-badge-approaching" },
    ontrack: { emoji: "🟢", text: "On Track", cls: "iq-badge-pass" },
  };
  const { emoji, text, cls } = map[risk];
  return <span className={cls}>{emoji} {text}</span>;
};

export const GrowthBadge: React.FC<{ value: number | null }> = ({ value }) => {
  if (value == null) return <span className="iq-growth-flat">—</span>;
  if (value > 0) return <span className="iq-growth-up">▲ +{Math.round(value)}</span>;
  if (value < 0) return <span className="iq-growth-down">▼ {Math.round(value)}</span>;
  return <span className="iq-growth-flat">=0</span>;
};

export const ScoreChip: React.FC<{ score: number | null }> = ({ score }) => {
  if (score == null) return <span className="text-muted-foreground">—</span>;
  return <span className="iq-score-chip">{score}</span>;
};

export const SparkLine: React.FC<{ scores: number[] }> = ({ scores }) => {
  if (!scores || scores.length === 0) return null;
  const max = Math.max(...scores);
  const min = Math.min(...scores);
  const range = max - min || 1;
  return (
    <span className="inline-flex items-end gap-0.5 h-5 align-middle">
      {scores.map((s, i) => {
        const h = Math.max(4, Math.round(18 * (s - min) / range + 4));
        return (
          <span
            key={i}
            className="rounded-t"
            style={{
              width: 6,
              height: h,
              minHeight: 3,
              background: i === scores.length - 1 ? "hsl(var(--primary))" : "hsl(var(--lavender-dark))",
            }}
            title={String(s)}
          />
        );
      })}
    </span>
  );
};
