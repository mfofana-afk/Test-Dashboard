import React from "react";
import {
  D, buildLatest, buildIRLookup, buildILLookup, buildStuLookup, buildTeachMap,
  stripGrade, LV_SHORT, getStudentRisk, getNextStep, profCounts,
  type Checkpoint
} from "@/data/dataUtils";
import { LevelBadge, RiskBadge, GrowthBadge, ScoreChip, SparkLine } from "@/components/Badges";
import { ProgressBar } from "@/components/StackedBar";

interface Props {
  studentName: string;
  onClose: () => void;
  latest: Record<string, Checkpoint>;
  byNameCP: Record<string, Checkpoint>;
  irLook: Record<string, Record<string, any>>;
  ilLook: Record<string, any>;
  stuLook: Record<string, any>;
  teachMap: Record<string, string>;
  focusSet: Set<string>;
}

export default function StudentModal({ studentName, onClose, latest, byNameCP, irLook, ilLook, stuLook, teachMap, focusSet }: Props) {
  const s = stuLook[studentName] || { n: studentName };
  const cpRecs = D.checkpoints.filter(r => r.n === studentName);
  const ir = irLook[studentName] || {};
  const il = ilLook[studentName];
  const isFoc = focusSet.has(studentName);
  const hr = s.hr || latest[studentName]?.hr || "";
  const teach = teachMap[hr] || teachMap[stripGrade(hr)] || "";
  const risk = getStudentRisk(studentName, latest, ilLook);
  const nextStep = getNextStep(studentName, latest, ilLook);

  // CP data by checkpoint
  const byCP: Record<number, Checkpoint[]> = {};
  cpRecs.forEach(r => { (byCP[r.cp] ??= []).push(r); });
  const allScores = cpRecs.filter(r => r.op === 1).sort((a, b) => a.cp - b.cp).map(r => r.sc).filter(Boolean) as number[];

  return (
    <div className="fixed inset-0 bg-navy/60 z-[1000] flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card rounded-2xl w-full max-w-[640px] max-h-[90vh] flex flex-col overflow-hidden" style={{ boxShadow: "0 24px 64px rgba(0,0,0,.3)" }} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="px-5 pt-4 pb-3 border-b border-border bg-secondary/30 shrink-0 flex justify-between items-start">
          <div className="min-w-0">
            <h3 className="text-base font-bold text-navy">{studentName} {isFoc && <span className="text-level-at">⭐</span>}</h3>
            <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-1.5 items-center">
              {s.gr && <span>Grade {s.gr}</span>}
              {hr && <span>· {stripGrade(hr)}</span>}
              {teach && <span>· {teach}</span>}
              {s.sp === "Yes" && <span className="iq-badge-approaching text-[9px]">IEP</span>}
              {s.el === "Yes" && <span className="iq-badge-track text-[9px]">EL</span>}
            </div>
          </div>
          <button className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:bg-lavender shrink-0" onClick={onClose}>✕</button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto flex-1">
          {/* Risk & Next Step */}
          <div className="px-5 py-4 border-b border-border">
            <div className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground mb-2">📋 Student Intelligence</div>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="bg-secondary rounded-lg p-3">
                <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider">Risk Level</div>
                <div className="mt-1"><RiskBadge risk={risk} /></div>
              </div>
              <div className="bg-secondary rounded-lg p-3">
                <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider">Mastery Level</div>
                <div className="mt-1"><LevelBadge level={latest[studentName]?.lv || null} /></div>
              </div>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider mb-1">🎯 Next Instructional Step</div>
              <p className="text-sm">{nextStep}</p>
            </div>
          </div>

          {/* ILEARN Readiness */}
          {il && (
            <div className="px-5 py-4 border-b border-border">
              <div className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground mb-2">🎯 ILEARN Readiness</div>
              <div className="flex gap-3 items-start rounded-lg p-3" style={{
                background: il.cat === "Likely to Pass" ? "linear-gradient(135deg, #f0fdf4, #dcfce7)" :
                  il.cat === "On Track" ? "linear-gradient(135deg, #eff6ff, #dbeafe)" :
                  il.cat === "Approaching" ? "linear-gradient(135deg, #fffbeb, #fef3c7)" :
                  "linear-gradient(135deg, #fff5f5, #fee2e2)"
              }}>
                <div className="relative w-11 h-11 shrink-0">
                  <svg width="44" height="44" viewBox="0 0 44 44" style={{ transform: "rotate(-90deg)" }}>
                    <circle cx="22" cy="22" r="17" fill="none" stroke="hsl(var(--lavender-dark))" strokeWidth="5" />
                    <circle cx="22" cy="22" r="17" fill="none" stroke={il.cat === "Likely to Pass" ? "#10b981" : il.cat === "On Track" ? "#3b82f6" : il.cat === "Approaching" ? "#f59e0b" : "#ef4444"} strokeWidth="5" strokeDasharray={`${(il.score / 100) * 106.8} 106.8`} strokeLinecap="round" />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-navy">{il.score}</div>
                </div>
                <div className="flex-1">
                  <LevelBadge level={il.cat} />
                  <div className="text-xs text-muted-foreground mt-1">Score: <strong>{il.score} / 100</strong></div>
                  <div className="w-full h-2 rounded-full bg-primary-foreground/30 overflow-hidden mt-2">
                    <div className="h-full rounded-full" style={{ width: `${il.score}%`, background: il.cat === "Likely to Pass" ? "#10b981" : il.cat === "On Track" ? "#3b82f6" : il.cat === "Approaching" ? "#f59e0b" : "#ef4444" }} />
                  </div>
                  {il.factors?.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {il.factors.map((f: string[], i: number) => (
                        <span key={i} className="text-[10px] bg-primary-foreground/50 border border-border/50 rounded px-1.5 py-0.5">
                          <strong>{f[0]}:</strong> {f[1]}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* iReady */}
          {(ir.boy || ir.moy) && (
            <div className="px-5 py-4 border-b border-border">
              <div className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground mb-2">📈 iReady</div>
              <div className="grid grid-cols-2 gap-2">
                {ir.boy && (
                  <>
                    <div className="bg-secondary rounded-lg p-3"><div className="text-[10px] text-muted-foreground font-semibold uppercase">BOY Score</div><div className="text-base font-bold text-navy mt-1">{ir.boy.sc}</div></div>
                    <div className="bg-secondary rounded-lg p-3"><div className="text-[10px] text-muted-foreground font-semibold uppercase">BOY Relative</div><div className="text-xs mt-1">{ir.boy.rp || "—"}</div></div>
                  </>
                )}
                {ir.moy && (
                  <>
                    <div className="bg-secondary rounded-lg p-3"><div className="text-[10px] text-muted-foreground font-semibold uppercase">MOY Score</div><div className="text-base font-bold text-navy mt-1">{ir.moy.sc}</div></div>
                    <div className="bg-secondary rounded-lg p-3"><div className="text-[10px] text-muted-foreground font-semibold uppercase">MOY Relative</div><div className="text-xs mt-1">{ir.moy.rp || "—"}</div></div>
                  </>
                )}
                {ir.boy && ir.moy && (
                  <div className="bg-secondary rounded-lg p-3"><div className="text-[10px] text-muted-foreground font-semibold uppercase">Growth</div><div className="mt-1"><GrowthBadge value={ir.moy.sc - ir.boy.sc} /></div></div>
                )}
              </div>
            </div>
          )}

          {/* Checkpoint Journey */}
          {cpRecs.length > 0 && (
            <div className="px-5 py-4 border-b border-border">
              <div className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground mb-2">
                ✅ Checkpoint Journey <SparkLine scores={allScores} />
              </div>
              {Object.keys(byCP).sort().map(cpNum => {
                const recs = byCP[+cpNum].sort((a, b) => a.op - b.op);
                return (
                  <div key={cpNum} className="mb-3">
                    <div className="text-xs font-semibold text-navy-light mb-1.5">CP{cpNum} — {recs[0]?.topic || ""}</div>
                    {recs.map(r => (
                      <div key={`${r.cp}-${r.op}`} className="bg-secondary rounded-lg p-3 mb-1.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-semibold">Opp {r.op}</span>
                          <LevelBadge level={r.lv} />
                          <ScoreChip score={r.sc} />
                          <span className="text-xs text-muted-foreground">{r.sp_pct != null ? Math.round(r.sp_pct * 100) + "% state" : ""}</span>
                        </div>
                        {r.stds && Object.keys(r.stds).length > 0 && (
                          <div className="mt-2 flex flex-wrap gap-1">
                            {Object.entries(r.stds).map(([code, sd]) => {
                              const p = sd.possible > 0 ? sd.earned / sd.possible : null;
                              const cls = p == null ? "" : p >= 0.8 ? "bg-level-at-bg border-level-at text-level-at-text" : p >= 0.5 ? "bg-level-approaching-bg border-level-approaching text-level-approaching-text" : "bg-level-below-bg border-level-below text-level-below-text";
                              return (
                                <span key={code} className={`text-[10px] font-mono border rounded px-1.5 py-0.5 ${cls}`}>
                                  {code}: {sd.earned}/{sd.possible}
                                </span>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
