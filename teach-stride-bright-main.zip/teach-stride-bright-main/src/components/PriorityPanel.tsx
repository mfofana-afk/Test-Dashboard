import React from "react";
import { getTopPriorityStandards, D, buildLatest, buildILLookup } from "@/data/dataUtils";

const { latest } = buildLatest();

export default function PriorityPanel({ gradeFilter }: { gradeFilter?: number }) {
  const topStds = getTopPriorityStandards(gradeFilter);
  if (topStds.length === 0) return null;

  const totalStudents = Object.values(latest).filter(r => !gradeFilter || r.g === gradeFilter).length || 1;

  return (
    <div className="iq-priority-panel mb-5 animate-fade-in">
      <div className="flex items-center gap-2 mb-3">
        <span className="text-lg">🚀</span>
        <h2 className="text-lg font-bold">What Should We Teach Next?</h2>
      </div>
      <p className="text-sm opacity-80 mb-4">Top highest-leverage standards based on student performance data — i-LEARN aligned</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {topStds.slice(0, 3).map((std, i) => {
          const belowPct = Math.round((std.below / std.n) * 100);
          return (
            <div key={std.code} className="bg-primary-foreground/10 rounded-lg p-4 border border-primary-foreground/20">
              <div className="flex items-center gap-2 mb-2">
                <span className="bg-primary-foreground/20 rounded-md px-2 py-0.5 text-xs font-bold font-mono">{std.code}</span>
                {std.priority === "Essential" && <span className="bg-level-approaching text-primary-foreground rounded px-1.5 py-0.5 text-[9px] font-bold">ESSENTIAL</span>}
              </div>
              <div className="text-sm font-medium mb-2 opacity-90">{std.subdomain}</div>
              <div className="text-xs opacity-70 mb-3 line-clamp-2">{std.desc}</div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs opacity-70">Below proficiency:</span>
                  <span className="font-bold text-sm">{belowPct}%</span>
                  <span className="text-xs opacity-60">({std.below}/{std.n} students)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs opacity-70">Overall mastery:</span>
                  <span className="font-bold text-sm">{Math.round(std.mastery * 100)}%</span>
                </div>
                <div className="mt-2 pt-2 border-t border-primary-foreground/20">
                  <div className="text-[10px] uppercase tracking-wider opacity-60 mb-1">Action</div>
                  <div className="text-xs">
                    {belowPct > 60
                      ? "Whole-class reteach with scaffolded practice + annotation"
                      : belowPct > 40
                      ? "Small group targeted reteach for struggling students"
                      : "Targeted intervention for specific students below threshold"}
                  </div>
                </div>
                <div className="mt-1">
                  <div className="text-[10px] uppercase tracking-wider opacity-60 mb-1">Grouping</div>
                  <div className="text-xs">
                    Pull {std.below} students for {belowPct > 50 ? "structured small group instruction" : "brief pull-out sessions"}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
