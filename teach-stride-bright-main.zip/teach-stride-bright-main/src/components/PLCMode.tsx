import React, { useState } from "react";
import { getPLCInsights, getSkillGroups, D, buildLatest, buildILLookup, getStudentRisk, stripGrade } from "@/data/dataUtils";
import { LevelBadge, RiskBadge } from "@/components/Badges";
import { ProgressBar } from "@/components/StackedBar";

const { latest } = buildLatest();
const ilLook = buildILLookup();

export default function PLCMode({ onStudentClick }: { onStudentClick: (n: string) => void }) {
  const [active, setActive] = useState(false);
  const insights = getPLCInsights();

  if (!active) {
    return (
      <div className="animate-fade-in flex flex-col items-center justify-center py-20">
        <div className="text-center max-w-md">
          <div className="text-6xl mb-4">💬</div>
          <h2 className="text-2xl font-bold text-navy mb-2">PLC Meeting Mode</h2>
          <p className="text-muted-foreground mb-6">Generate key insights, student groups, priority standards, and discussion prompts for your PLC meeting.</p>
          <button
            className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-semibold text-base hover:opacity-90 transition-opacity"
            onClick={() => setActive(true)}
          >
            🚀 Start PLC Mode
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg font-bold text-navy">💬 PLC Meeting Mode</h2>
          <p className="text-sm text-muted-foreground">Auto-generated insights for your team meeting</p>
        </div>
        <button className="bg-secondary text-foreground px-4 py-2 rounded-lg text-sm font-medium hover:bg-lavender" onClick={() => setActive(false)}>Exit PLC Mode</button>
      </div>

      {/* Key Insights */}
      <div className="iq-priority-panel mb-5">
        <h3 className="text-base font-bold mb-3">📊 Key Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {insights.topStandards.slice(0, 3).map(std => (
            <div key={std.code} className="bg-primary-foreground/10 rounded-lg p-3 border border-primary-foreground/20">
              <div className="font-mono font-bold text-sm mb-1">{std.code}</div>
              <div className="text-xs opacity-80 mb-1">{std.subdomain}</div>
              <div className="text-sm font-bold">{Math.round(std.mastery * 100)}% mastery</div>
              <div className="text-xs opacity-70">{std.below} students struggling</div>
            </div>
          ))}
        </div>
      </div>

      {/* Priority Standards */}
      <div className="iq-card p-4 mb-5">
        <h3 className="text-sm font-bold text-navy mb-3">🎯 Priority Standards</h3>
        <div className="space-y-2">
          {insights.topStandards.map(std => (
            <div key={std.code} className="flex items-center gap-3 p-2 bg-secondary/50 rounded-lg">
              <span className="font-mono font-bold text-primary min-w-[60px]">{std.code}</span>
              <div className="flex-1">
                <div className="text-xs text-muted-foreground">{std.subdomain}</div>
                <ProgressBar value={std.mastery} variant="auto" height={5} />
              </div>
              <span className="text-destructive font-bold text-sm">{std.below}</span>
              <span className="text-xs text-muted-foreground">struggling</span>
            </div>
          ))}
        </div>
      </div>

      {/* Student Groups */}
      <div className="iq-card p-4 mb-5">
        <h3 className="text-sm font-bold text-navy mb-3">👥 Student Groups for Instruction</h3>
        {insights.groups.slice(0, 4).map((group, i) => (
          <div key={i} className="mb-3 p-3 bg-secondary/30 rounded-lg">
            <div className="font-semibold text-sm mb-1">{group.name}</div>
            <div className="text-xs text-muted-foreground mb-1">{group.students.length} students · Target: {group.standard}</div>
            <div className="text-xs mb-2">{group.strategy}</div>
            <div className="flex flex-wrap gap-1">
              {group.students.slice(0, 10).map(name => (
                <span key={name} className="iq-student-link text-[10px] bg-card border border-border rounded px-1.5 py-0.5" onClick={() => onStudentClick(name)}>{name}</span>
              ))}
              {group.students.length > 10 && <span className="text-[10px] text-muted-foreground">+{group.students.length - 10} more</span>}
            </div>
          </div>
        ))}
      </div>

      {/* Multi-skill stuck students */}
      {insights.multiSkillStuck.length > 0 && (
        <div className="iq-card p-4 mb-5">
          <h3 className="text-sm font-bold text-navy mb-3">⚠️ Students Stuck Across Multiple Skills ({insights.multiSkillStuck.length})</h3>
          <div className="flex flex-wrap gap-1.5">
            {insights.multiSkillStuck.map(name => (
              <span key={name} className="iq-student-link text-xs bg-level-below-bg border border-level-below rounded-md px-2 py-1" onClick={() => onStudentClick(name)}>
                🔴 {name}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Discussion Prompts */}
      <div className="iq-card p-4 mb-5">
        <h3 className="text-sm font-bold text-navy mb-3">💡 Discussion Prompts</h3>
        <div className="space-y-2">
          {insights.prompts.map((prompt, i) => (
            <div key={i} className="flex gap-2 p-2.5 bg-secondary/50 rounded-lg text-sm">
              <span className="text-primary font-bold">{i + 1}.</span>
              <span>{prompt}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Auto-generated Meeting Notes */}
      <div className="iq-card p-4">
        <h3 className="text-sm font-bold text-navy mb-3">📝 Auto-Generated Meeting Notes</h3>
        <div className="bg-secondary/50 rounded-lg p-4 text-sm space-y-2 font-mono text-xs">
          <p>PLC Meeting — {new Date().toLocaleDateString()}</p>
          <p>---</p>
          <p>PRIORITY STANDARDS:</p>
          {insights.topStandards.slice(0, 3).map(s => (
            <p key={s.code}>• {s.code} ({s.subdomain}): {Math.round(s.mastery * 100)}% mastery, {s.below} students below</p>
          ))}
          <p>---</p>
          <p>STUDENT GROUPS:</p>
          {insights.groups.slice(0, 3).map((g, i) => (
            <p key={i}>• {g.name}: {g.students.length} students → {g.strategy.slice(0, 60)}...</p>
          ))}
          <p>---</p>
          <p>AT-RISK STUDENTS: {Object.values(latest).filter(r => getStudentRisk(r.n, latest, ilLook) === "high").length} total</p>
          <p>BORDER STUDENTS: {D.ilearnReadiness.filter(r => r.score >= 35 && r.score <= 55).length} students near threshold</p>
        </div>
        <div className="mt-3 flex gap-2">
          <button className="bg-primary text-primary-foreground px-3 py-1.5 rounded-md text-xs font-medium hover:opacity-90" onClick={() => {
            const text = document.querySelector('.font-mono.text-xs')?.textContent || "";
            navigator.clipboard.writeText(text);
          }}>📋 Copy Notes</button>
        </div>
      </div>
    </div>
  );
}
