import React from "react";

interface KPICardProps {
  label: string;
  value: string | number;
  sub?: string;
  variant?: "total" | "above" | "at" | "approaching" | "below" | "pass" | "focus";
  onClick?: () => void;
}

const variantStripe: Record<string, string> = {
  total: "bg-gradient-to-r from-lavender-dark to-primary",
  above: "bg-gradient-to-r from-level-above-bg to-level-above",
  at: "bg-gradient-to-r from-level-at-bg to-level-at",
  approaching: "bg-gradient-to-r from-level-approaching-bg to-level-approaching",
  below: "bg-gradient-to-r from-level-below-bg to-level-below",
  pass: "bg-gradient-to-r from-level-at-bg to-level-at",
  focus: "bg-gradient-to-r from-primary/30 to-primary",
};

export const KPICard: React.FC<KPICardProps> = ({ label, value, sub, variant = "total", onClick }) => (
  <div
    className={`iq-card relative overflow-hidden p-3.5 ${onClick ? "cursor-pointer hover:shadow-md transition-shadow" : ""}`}
    onClick={onClick}
  >
    <div className={`absolute top-0 left-0 right-0 h-1 rounded-t-xl ${variantStripe[variant] || variantStripe.total}`} />
    <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">{label}</div>
    <div className="text-2xl font-bold text-navy tracking-tight">{value}</div>
    {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
  </div>
);

export default KPICard;
