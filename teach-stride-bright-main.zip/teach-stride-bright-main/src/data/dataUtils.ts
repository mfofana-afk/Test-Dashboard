import { kippData } from "./kippData";

// Types
export interface Student { n: string; stn: string; ge: string; et: string; sp: string; el: string; gr: number; hr: string; }
export interface Checkpoint { n: string; stn: string; g: number; hr: string; cp: number; op: number; topic: string; dt: string; sc: number | null; lv: string; sp_pct: number | null; s1: string; s2: string; sn1: string; sn2: string; stds: Record<string, { earned: number; possible: number }>; src: string; }
export interface IReady { n: string; gr: number; pd: string; sc: number; pl: string; rp: string; pct: number | null; q: string; }
export interface CP1Compare { n: string; g: number; hr: string; l1: string; sc1: number | null; sp1: number | null; l2: string; sc2: number | null; sp2: number | null; dsc: number | null; dlv: number | null; }
export interface Classroom { Grade: number; Class: string; Teacher: string; }
export interface StandardRecord { code: string; cp: number; op: number; g: number; e: number; p: number; n: number; hrs: Record<string, any>; cat: string; desc: string; priority: string; students: { n: string; hr: string; e: number; p: number; pct: number | null }[]; }
export interface IAFEntry { desc: string; priority: string; subdomain: string; grade: number; cp1?: boolean; cp2?: boolean; cp3?: boolean; }
export interface FocusStudent { n: string; g: number; hr: string; teacher: string; lv: string; sc: number | null; cp: number; l1: string; l2: string; l3: string; scores: number[]; ir_sc: number | null; ir_rp: string; il_score: number; il_cat: string; il_factors: string[][]; trending_up: boolean; opp_improved: boolean; sp: string; el: string; }
export interface GrowthSeries { g: number; cp: number; op: number; n: number; at_above: number; above: number; at: number; app: number; below: number; }
export interface ILearnReadiness { n: string; score: number; cat: string; factors: string[][]; }

export const D = {
  students: kippData.students as unknown as Student[],
  checkpoints: kippData.checkpoints as unknown as Checkpoint[],
  iready: kippData.iready as unknown as IReady[],
  cp1c: kippData.cp1c as unknown as CP1Compare[],
  classrooms: kippData.classrooms as unknown as Classroom[],
  standards: kippData.standards as unknown as StandardRecord[],
  iaf: kippData.iaf as unknown as Record<string, IAFEntry>,
  focusStudents: kippData.focusStudents as unknown as FocusStudent[],
  growthSeries: kippData.growthSeries as unknown as GrowthSeries[],
  ilearnReadiness: kippData.ilearnReadiness as unknown as ILearnReadiness[],
};

// ── LOOKUPS ──
export const LV_ORDER = ["Above Proficiency", "At Proficiency", "Approaching Proficiency", "Below Proficiency"] as const;
export const LV_SHORT: Record<string, string> = {
  "Above Proficiency": "Above", "At Proficiency": "At",
  "Approaching Proficiency": "Approaching", "Below Proficiency": "Below"
};
export const IL_CATS = ["Likely to Pass", "On Track", "Approaching", "Needs Support"] as const;

export function buildLatest() {
  const latest: Record<string, Checkpoint> = {};
  const byNameCP: Record<string, Checkpoint> = {};
  D.checkpoints.forEach(r => {
    const cur = latest[r.n];
    if (!cur || r.cp > cur.cp || (r.cp === cur.cp && r.op > cur.op)) latest[r.n] = r;
    const k = `${r.n}__${r.cp}`;
    if (!byNameCP[k] || r.op > byNameCP[k].op) byNameCP[k] = r;
    byNameCP[`${r.n}__${r.cp}__${r.op}`] = r;
  });
  return { latest, byNameCP };
}

export function buildIRLookup() {
  const irLook: Record<string, Record<string, IReady>> = {};
  D.iready.forEach(r => {
    if (!irLook[r.n]) irLook[r.n] = {};
    irLook[r.n][r.pd] = r;
  });
  return irLook;
}

export function buildTeachMap() {
  const m: Record<string, string> = {};
  D.classrooms.forEach(cl => {
    m[cl.Class] = cl.Teacher;
    m[cl.Grade + cl.Class] = cl.Teacher;
  });
  return m;
}

export function buildILLookup() {
  const m: Record<string, ILearnReadiness> = {};
  D.ilearnReadiness.forEach(r => { m[r.n] = r; });
  return m;
}

export function buildStuLookup() {
  const m: Record<string, Student> = {};
  D.students.forEach(s => { m[s.n] = s; });
  return m;
}

export function profCounts(recs: { lv: string }[]) {
  const c = { "Above Proficiency": 0, "At Proficiency": 0, "Approaching Proficiency": 0, "Below Proficiency": 0 };
  recs.forEach(r => { if (r.lv in c) (c as any)[r.lv]++; });
  return c;
}

export function stripGrade(hr: string) {
  return hr ? hr.replace(/^\d+/, "") : hr;
}

export function pct(f: number | null) {
  return f == null ? "—" : Math.round(f * 100) + "%";
}

// Get top priority standards (lowest mastery, most students)
export function getTopPriorityStandards(gradeFilter?: number) {
  const grouped: Record<string, { code: string; desc: string; g: number; mastery: number; n: number; below: number; priority: string; subdomain: string }> = {};
  D.standards.forEach(s => {
    if (gradeFilter && s.g !== gradeFilter) return;
    const key = s.code;
    if (!grouped[key]) {
      const iaf = D.iaf[s.code];
      const m = s.p > 0 ? s.e / s.p : 1;
      const belowCount = s.students.filter(st => st.pct != null && st.pct < 0.6).length;
      grouped[key] = { code: s.code, desc: iaf?.desc || s.desc || "", g: s.g, mastery: m, n: s.n, below: belowCount, priority: iaf?.priority || "", subdomain: iaf?.subdomain || s.cat || "" };
    }
  });
  return Object.values(grouped)
    .filter(s => s.mastery < 0.7)
    .sort((a, b) => a.mastery - b.mastery)
    .slice(0, 5);
}

// Auto-group students by skill gap
export function getSkillGroups() {
  const { latest } = buildLatest();
  const ilLook = buildILLookup();
  const groups: { name: string; level: string; students: string[]; standard: string; standardDesc: string; strategy: string; focus: string; }[] = [];
  
  // Group by performance level
  const byLevel: Record<string, string[]> = { below: [], approaching: [], at: [], above: [] };
  Object.values(latest).forEach(r => {
    if (r.lv === "Below Proficiency") byLevel.below.push(r.n);
    else if (r.lv === "Approaching Proficiency") byLevel.approaching.push(r.n);
    else if (r.lv === "At Proficiency") byLevel.at.push(r.n);
    else if (r.lv === "Above Proficiency") byLevel.above.push(r.n);
  });

  const topStds = getTopPriorityStandards();
  const weakestStd = topStds[0];

  if (byLevel.below.length > 0) {
    groups.push({
      name: "🔴 Intensive Support",
      level: "Below Proficiency",
      students: byLevel.below.sort(),
      standard: weakestStd?.code || "Multiple",
      standardDesc: weakestStd?.desc || "Multiple standards below mastery",
      strategy: "Small group direct instruction with scaffolded practice, visual models, and daily progress monitoring",
      focus: "Build foundational understanding through concrete-representational-abstract sequence"
    });
  }
  if (byLevel.approaching.length > 0) {
    const topForApproaching = topStds[1] || topStds[0];
    groups.push({
      name: "🟡 Strategic Support",
      level: "Approaching Proficiency",
      students: byLevel.approaching.sort(),
      standard: topForApproaching?.code || "Multiple",
      standardDesc: topForApproaching?.desc || "",
      strategy: "Guided practice with error analysis, peer collaboration, targeted re-teaching of specific misconceptions",
      focus: "Close specific skill gaps through deliberate practice and immediate feedback"
    });
  }

  // Border students (ILEARN 35-55) as a special group
  const borderStudents = D.ilearnReadiness
    .filter(r => r.score >= 35 && r.score <= 55)
    .sort((a, b) => b.score - a.score)
    .map(r => r.n);
  
  if (borderStudents.length > 0) {
    groups.push({
      name: "⚡ Quick Wins (Border Students)",
      level: "Near Threshold",
      students: borderStudents.slice(0, 20),
      standard: topStds[0]?.code || "Priority",
      standardDesc: "Students closest to passing threshold — highest ROI for targeted intervention",
      strategy: "High-frequency, focused mini-lessons on 1-2 priority standards with daily formative assessment",
      focus: "Push students across the proficiency threshold with targeted, high-impact instruction"
    });
  }

  if (byLevel.at.length > 0) {
    groups.push({
      name: "🟢 On Track — Enrichment",
      level: "At Proficiency",
      students: byLevel.at.sort(),
      standard: "Grade-level extension",
      standardDesc: "Standards mastered — ready for deeper application",
      strategy: "Independent application tasks, peer tutoring opportunities, enrichment problems",
      focus: "Deepen understanding and build transfer skills through complex application"
    });
  }
  if (byLevel.above.length > 0) {
    groups.push({
      name: "🔵 Advanced — Extension",
      level: "Above Proficiency",
      students: byLevel.above.sort(),
      standard: "Above-grade extension",
      standardDesc: "Consistently exceeding grade-level expectations",
      strategy: "Complex problem-solving, cross-standard connections, student-led investigations",
      focus: "Challenge with above-grade-level tasks and leadership opportunities"
    });
  }

  return groups;
}

// Get student risk level
export function getStudentRisk(name: string, latest: Record<string, Checkpoint>, ilLook: Record<string, ILearnReadiness>): "high" | "watch" | "ontrack" {
  const il = ilLook[name];
  const lat = latest[name];
  if (!il && !lat) return "high";
  if (il) {
    if (il.cat === "Needs Support" || il.score < 32) return "high";
    if (il.cat === "Approaching" || il.score < 50) return "watch";
  }
  if (lat) {
    if (lat.lv === "Below Proficiency") return "high";
    if (lat.lv === "Approaching Proficiency") return "watch";
  }
  return "ontrack";
}

// Get next instructional step for a student
export function getNextStep(name: string, latest: Record<string, Checkpoint>, ilLook: Record<string, ILearnReadiness>): string {
  const lat = latest[name];
  const il = ilLook[name];
  if (!lat) return "Gather baseline assessment data";
  
  // Find their weakest standard
  if (lat.stds) {
    const weak = Object.entries(lat.stds)
      .filter(([, v]) => v.possible > 0)
      .map(([code, v]) => ({ code, pct: v.earned / v.possible }))
      .sort((a, b) => a.pct - b.pct);
    
    if (weak.length > 0 && weak[0].pct < 0.6) {
      const iaf = D.iaf[weak[0].code];
      return `Reteach ${weak[0].code} (${iaf?.subdomain || ""}): ${Math.round(weak[0].pct * 100)}% mastery — use targeted practice`;
    }
  }
  
  if (lat.lv === "Below Proficiency") return "Intensive small group intervention — focus on foundational skills with daily progress monitoring";
  if (lat.lv === "Approaching Proficiency") return "Strategic reteach with guided practice — target specific misconceptions";
  if (lat.lv === "At Proficiency") return "Maintain with independent practice — extend through application tasks";
  return "Enrichment and extension activities — deepen understanding through complex problems";
}

// Admin: grade-level summary
export function getGradeSummary() {
  const { latest } = buildLatest();
  const ilLook = buildILLookup();
  const grades = [4, 5, 6].map(g => {
    const recs = Object.values(latest).filter(r => r.g === g);
    const counts = profCounts(recs);
    const total = recs.length || 1;
    const atAbove = Math.round((counts["Above Proficiency"] + counts["At Proficiency"]) / total * 100);
    const ilRecs = D.ilearnReadiness.filter(r => { const l = latest[r.n]; return l && l.g === g; });
    const ilPass = ilRecs.filter(r => r.cat === "Likely to Pass" || r.cat === "On Track").length;
    const ilPassPct = ilRecs.length ? Math.round(ilPass / ilRecs.length * 100) : 0;
    const atRisk = Object.values(latest).filter(r => r.g === g && getStudentRisk(r.n, latest, ilLook) === "high").length;
    const topStds = getTopPriorityStandards(g);
    return { grade: g, total: recs.length, atAbovePct: atAbove, counts, ilPassPct, ilPass, atRisk, weakestStandards: topStds.slice(0, 2) };
  });
  return grades;
}

// School-wide weakest standards
export function getSchoolWeakStandards() {
  return getTopPriorityStandards().slice(0, 5);
}

// PLC discussion prompts
export function getPLCInsights() {
  const { latest } = buildLatest();
  const ilLook = buildILLookup();
  const groups = getSkillGroups();
  const topStds = getTopPriorityStandards();
  
  // Students stuck across multiple skills
  const multiSkillStuck: string[] = [];
  Object.entries(latest).forEach(([name, r]) => {
    if (r.stds) {
      const weakCount = Object.entries(r.stds).filter(([, v]) => v.possible > 0 && v.earned / v.possible < 0.5).length;
      if (weakCount >= 2) multiSkillStuck.push(name);
    }
  });

  return {
    topStandards: topStds,
    groups,
    multiSkillStuck: multiSkillStuck.slice(0, 15),
    prompts: [
      `Which students are stuck across multiple skills? (${multiSkillStuck.length} identified)`,
      `Which standard impacts the most students? (${topStds[0]?.code}: ${topStds[0]?.below} students below 60%)`,
      `What instructional adjustments should we make based on Opp1 vs Opp2 trends?`,
      `How can we leverage our ${groups.find(g => g.level === "Near Threshold")?.students.length || 0} border students for quick wins?`,
      `Which teachers have highest growth? What strategies can we replicate?`,
    ]
  };
}
